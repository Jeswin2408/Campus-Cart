package com.example.cart;

import com.example.cart.ModelCategory;

public interface RvListenerCategory {

    void onCategoryClick(ModelCategory modelCategory);
}
