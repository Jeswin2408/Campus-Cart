package com.example.cart;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.cart.databinding.ActivityAdDetailsBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class AdDetailsActivity extends AppCompatActivity {

    private ActivityAdDetailsBinding binding;
    private static final String TAG = "AD_DETAILS_TAG";

    private FirebaseAuth firebaseAuth;
    private String adId = "";
    private double adLatitude = 0;
    private double adLongitude = 0;
    private String sellerUid = null;
    private String sellerPhone = "";
    private boolean favorite = false;
    private ArrayList<ModelImageSlider> imageSliderArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        binding = ActivityAdDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initially hide certain buttons
        binding.toolbarEditBtn.setVisibility(View.GONE);
        binding.toolbarDeleteBtn.setVisibility(View.GONE);
        binding.chatBtn.setVisibility(View.GONE);
        binding.callBtn.setVisibility(View.GONE);
        binding.smsBtn.setVisibility(View.GONE);

        adId = getIntent().getStringExtra("adId");
        Log.d(TAG, "onCreate: adId: " + adId);

        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() != null) {
            checkIsFavourite();
        }

        loadAdDetails();
        loadAdImage();

        // Button Listeners
        binding.toolbarBackBtn.setOnClickListener(v -> onBackPressed());

        binding.toolbarDeleteBtn.setOnClickListener(v -> showDeleteDialog());

        binding.toolbarEditBtn.setOnClickListener(v -> {
            editOptions();
            // Code for editing functionality
        });


        binding.toolbarFavBtn.setOnClickListener(v -> {
            if (favorite) {
                Utils.removeFromFavorite(AdDetailsActivity.this, adId);
            } else {
                Utils.addToFavorite(AdDetailsActivity.this, adId);
            }
        });

        binding.sellerProfileCv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdDetailsActivity.this, AdSellerProfileActivity.class);
                intent.putExtra("sellerUid", sellerUid);
                startActivity(intent);

            }
        });
        binding.chatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(AdDetailsActivity.this, ChatActivity.class);
                intent.putExtra("receiptUid",sellerUid);
                startActivity(intent);

            }
        });

        binding.callBtn.setOnClickListener(v -> Utils.callIntent(AdDetailsActivity.this, sellerPhone));

        binding.smsBtn.setOnClickListener(v -> Utils.smsIntent(AdDetailsActivity.this, sellerPhone));
    }

    private void showDeleteDialog() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Delete Ad")
                .setMessage("Are you sure you want to delete this Ad?")
                .setPositiveButton("DELETE", (dialog, which) -> deleteAd())
                .setNegativeButton("CANCEL", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void showMarkAsSoldDialog() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Mark as Sold")
                .setMessage("Are you sure you want to mark this Ad as sold?")
                .setPositiveButton("SOLD", (dialog, which) -> markAdAsSold())
                .setNegativeButton("CANCEL", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void markAdAsSold() {
        Log.d(TAG, "markAdAsSold: Marking as sold...");
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("status", "" + Utils.AD_STATUS_SOLD);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Ads");
        ref.child(adId)
                .updateChildren(hashMap)
                .addOnSuccessListener(unused -> {
                    Log.d(TAG, "onSuccess: Marked as sold");
                    Utils.toast(AdDetailsActivity.this, "Marked as sold");
                })
                .addOnFailureListener(e -> {
                    Log.d(TAG, "onFailure: ", e);
                    Utils.toast(AdDetailsActivity.this, "Failed to mark as sold due to " + e.getMessage());
                });
    }

    private void loadAdDetails() {
        Log.d(TAG, "loadAdDetails: Loading ad details");

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Ads");
        ref.child(adId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    ModelAd modelAd = snapshot.getValue(ModelAd.class);

                    if (modelAd != null) {
                        sellerUid = modelAd.getUid();
                        String title = modelAd.getTitle();
                        String description = modelAd.getDescription();
                        String address = modelAd.getAddress();
                        String price = modelAd.getPrice();
                        String brandName = modelAd.getBrandName();  // Retrieve the brand name
                        adLatitude = modelAd.getLatitude();
                        adLongitude = modelAd.getLongitude();
                        long timestamp = modelAd.getTimestamp();
                        String category = modelAd.getCategory() != null ? modelAd.getCategory() : "No Category";


                        String formattedDate = Utils.formatTimestampDate(timestamp);

                        binding.titleTv.setText(title);
                        binding.descriptionTv.setText(description);
                        binding.addressTv.setText(address);
                        binding.priceTv.setText(price);
                        binding.dateTv.setText(formattedDate);
                        binding.brandNameTv.setText(brandName);  // Display the brand name

                        if (firebaseAuth.getUid().equals(sellerUid)) {
                            binding.toolbarEditBtn.setVisibility(View.VISIBLE);
                            binding.toolbarDeleteBtn.setVisibility(View.VISIBLE);
                        } else {
                            binding.chatBtn.setVisibility(View.VISIBLE);
                            binding.callBtn.setVisibility(View.VISIBLE);
                            binding.smsBtn.setVisibility(View.VISIBLE);
                            binding.categoryTv.setText(category);

                        }

                        loadSellerDetails();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "onDataChange: ", e);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }


    private void loadSellerDetails() {
        Log.d(TAG, "loadSellerDetails: Loading seller details");

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(sellerUid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    String phoneCode = "" + snapshot.child("phoneCode").getValue();
                    String phoneNumber = "" + snapshot.child("phoneNumber").getValue();
                    String name = "" + snapshot.child("name").getValue();
                    String profileImageUrl = "" + snapshot.child("profileImageUrl").getValue();
                    long timestamp = (Long) snapshot.child("timestamp").getValue();

                    String formattedDate = Utils.formatTimestampDate(timestamp);
                    sellerPhone = phoneCode + phoneNumber;

                    binding.sellerNameTv.setText(name);
                    binding.memberSinceTv.setText(formattedDate);

                    Glide.with(AdDetailsActivity.this)
                            .load(profileImageUrl)
                            .placeholder(R.drawable.ic_person_white)
                            .into(binding.sellerProfileIv);
                } catch (Exception e) {
                    Log.e(TAG, "onDataChange: ", e);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void checkIsFavourite() {
        Log.d(TAG, "checkIsFavourite: Checking if favorite");

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid()).child("Favourites").child(adId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        favorite = snapshot.exists();
                        binding.toolbarFavBtn.setImageResource(favorite ? R.drawable.ic_fav_yes : R.drawable.ic_fav_no);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    private void loadAdImage() {
        Log.d(TAG, "loadAdImages: Loading ad images");

        imageSliderArrayList = new ArrayList<>();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Ads");
        ref.child(adId).child("Images").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                imageSliderArrayList.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    ModelImageSlider modelImageSlider = ds.getValue(ModelImageSlider.class);
                    imageSliderArrayList.add(modelImageSlider);
                }

                AdapterImageSlider adapterImageSlider = new AdapterImageSlider(AdDetailsActivity.this, imageSliderArrayList);
                binding.imageSliderVp.setAdapter(adapterImageSlider);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void deleteAd() {
        Log.d(TAG, "deleteAd: Deleting ad");

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Ads");
        ref.child(adId).removeValue()
                .addOnSuccessListener(unused -> {
                    Log.d(TAG, "onSuccess: Deleted");
                    Utils.toast(AdDetailsActivity.this, "Deleted");
                    finishAffinity();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "onFailure: ", e);
                    Utils.toast(AdDetailsActivity.this, "Failed to delete due to " + e.getMessage());
                });
    }
    private void editOptions(){
        Log.d(TAG, "editOptions: ");

        PopupMenu popupMenu = new PopupMenu(this,binding.toolbarEditBtn);
        popupMenu.getMenu().add(Menu.NONE, 0, 0, "Edit");
        popupMenu.getMenu().add(Menu.NONE, 1,1,"Mark As sold");
        popupMenu.show();

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int itemId = menuItem.getItemId();

                if (itemId == 0 ){
                    Intent intent = new Intent(AdDetailsActivity.this, AdCreateActivity.class);
                    intent.putExtra("isEditMode",true);
                    intent.putExtra("adId",adId);
                    startActivity(intent);
                }else if(itemId == 1){

                    showMarkAsSoldDialog();
                }
                return true;
            }
        });
    }
}
