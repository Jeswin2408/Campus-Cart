package com.example.cart;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public class AppVisibilityTracker implements Application.ActivityLifecycleCallbacks {
    private static int activityReferences = 0;
    private static boolean isActivityChangingConfigurations = false;

    public static boolean isAppInForeground() {
        return activityReferences > 0 && !isActivityChangingConfigurations;
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

    @Override
    public void onActivityStarted(Activity activity) {
        if (++activityReferences == 1 && !isActivityChangingConfigurations) {
            // App enters foreground
        }
    }

    @Override
    public void onActivityResumed(Activity activity) {}

    @Override
    public void onActivityPaused(Activity activity) {}

    @Override
    public void onActivityStopped(Activity activity) {
        isActivityChangingConfigurations = activity.isChangingConfigurations();
        if (--activityReferences == 0 && !isActivityChangingConfigurations) {
            // App enters background
        }
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

    @Override
    public void onActivityDestroyed(Activity activity) {}
}
