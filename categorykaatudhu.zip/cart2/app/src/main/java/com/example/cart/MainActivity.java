package com.example.cart;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentTransaction;

import com.example.cart.AccountFragment;
import com.example.cart.ChatsFragment;
import com.example.cart.HomeFragment;
import com.example.cart.MyAdsFragment;
import com.example.cart.R;
import com.example.cart.Utils;
import com.example.cart.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseRef; // Realtime Database reference

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        firebaseAuth = FirebaseAuth.getInstance();
        databaseRef = FirebaseDatabase.getInstance().getReference(); // Initialize Realtime Database

        // Check if user is logged in, if not, redirect to login option
        if (firebaseAuth.getCurrentUser() == null) {
            startLoginOption();
        }

        // Show the Home fragment initially
        showHomeFragment();

        // Handle bottom navigation item selection
        binding.bottomNv.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.menu_home) {
                    showHomeFragment();
                    return true;
                } else if (itemId == R.id.menu_chats) {
                    if (firebaseAuth.getCurrentUser() == null) {
                        Utils.toast(MainActivity.this, "Login Required...");
                        startLoginOption();
                        return false;
                    } else {
                        showChatFragment();
                        return true;
                    }
                } else if (itemId == R.id.menu_my_ads) {
                    if (firebaseAuth.getCurrentUser() == null) {
                        Utils.toast(MainActivity.this, "Login Required...");
                        startLoginOption();
                        return false;
                    } else {
                        showMyAdsFragment();
                        return true;
                    }
                } else if (itemId == R.id.menu_account) {
                    if (firebaseAuth.getCurrentUser() == null) {
                        Utils.toast(MainActivity.this, "Login Required...");
                        startLoginOption();
                        return false;
                    } else {
                        showAccountFragment();
                        return true;
                    }
                } else {
                    return false;
                }
            }
        });

        // Handle window insets (system bars)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set up the floating action button to navigate to the AdCreateActivity
        binding.sellFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, AdCreateActivity.class));
            }
        });

        // Retrieve the FCM token
        getFCMToken();
    }

    // Method to retrieve Firebase Cloud Messaging token
    public void getFCMToken() {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if (task.isSuccessful()) {
                    String token = task.getResult();
                    Log.i("FCM Token", token); // Log the token for debugging purposes

                    // Upload token to Realtime Database if user is logged in
                    if (firebaseAuth.getCurrentUser() != null) {
                        String uid = firebaseAuth.getCurrentUser().getUid();
                        uploadTokenToRealtimeDatabase(uid, token);
                    }
                } else {
                    Log.e("FCM Error", "Fetching FCM registration token failed", task.getException());
                }
            }
        });
    }

    // Method to upload FCM token to Realtime Database
    private void uploadTokenToRealtimeDatabase(String uid, String token) {
        // Set the FCM token under the user's UID in the database
        Map<String, Object> tokenMap = new HashMap<>();
        tokenMap.put("fcmToken", token);

        databaseRef.child("users").child(uid).updateChildren(tokenMap)
                .addOnSuccessListener(aVoid -> Log.i("RealtimeDB", "FCM token uploaded successfully"))
                .addOnFailureListener(e -> Log.e("RealtimeDB Error", "Failed to upload FCM token", e));
    }

    // Method to display the Home fragment
    private void showHomeFragment() {
        binding.toolbarTitleTv.setText("Home");
        HomeFragment fragment = new HomeFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(binding.fragmentsFl.getId(), fragment, "HomeFragment");
        fragmentTransaction.commit();
    }

    // Method to display the Chats fragment
    private void showChatFragment() {
        binding.toolbarTitleTv.setText("Chats");
        ChatsFragment fragment = new ChatsFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(binding.fragmentsFl.getId(), fragment, "ChatsFragment");
        fragmentTransaction.commit();
    }

    // Method to display the My Ads fragment
    private void showMyAdsFragment() {
        binding.toolbarTitleTv.setText("My Ads");
        MyAdsFragment fragment = new MyAdsFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(binding.fragmentsFl.getId(), fragment, "MyAdsFragment");
        fragmentTransaction.commit();
    }

    // Method to display the Account fragment
    private void showAccountFragment() {
        binding.toolbarTitleTv.setText("Account");
        AccountFragment fragment = new AccountFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(binding.fragmentsFl.getId(), fragment, "AccountFragment");
        fragmentTransaction.commit();
    }

    // Method to start the login options activity
    private void startLoginOption() {
        startActivity(new Intent(this, LoginOptionsActivity.class));
    }
}
