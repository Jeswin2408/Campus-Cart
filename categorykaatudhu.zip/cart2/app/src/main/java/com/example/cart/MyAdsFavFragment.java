package com.example.cart;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.cart.AdapterAd;
import com.example.cart.databinding.FragmentMyAdsFavBinding;
import com.example.cart.ModelAd;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MyAdsFavFragment extends Fragment {

    private FragmentMyAdsFavBinding binding;
    private static final String TAG = "FAV_TAG";
    private Context mContext;
    private FirebaseAuth firebaseAuth;
    private ArrayList<ModelAd> adArrayList;
    private AdapterAd adapterAd;

    public MyAdsFavFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        mContext = context;
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentMyAdsFavBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        firebaseAuth = FirebaseAuth.getInstance();
        loadAds();

        binding.searchEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                try {
                    String query = charSequence.toString();
                    adapterAd.getFilter().filter(query);
                } catch (Exception e) {
                    Log.e(TAG, "onTextChanged: ", e);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    private void loadAds() {
        Log.d(TAG, "loadAds: ");
        adArrayList = new ArrayList<>();
        DatabaseReference favRef = FirebaseDatabase.getInstance().getReference("Users");
        favRef.child(firebaseAuth.getUid()).child("Favorites")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        adArrayList.clear();

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String adId = "" + ds.child("adId").getValue();
                            Log.d(TAG, "onDataChange: adId: " + adId);

                            DatabaseReference adRef = FirebaseDatabase.getInstance().getReference("Ads");
                            adRef.child(adId)
                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            try {
                                                ModelAd modelAd = snapshot.getValue(ModelAd.class);

                                                // If the ad exists and is not deleted, add it to the list
                                                if (modelAd != null) {
                                                    // If the ad is deleted, add a placeholder message
                                                    if (modelAd.isDeleted()) {
                                                        modelAd.setTitle("This ad was deleted by the user");
                                                        adArrayList.add(modelAd); // Add it as deleted
                                                    } else {
                                                        adArrayList.add(modelAd); // Normal ad
                                                    }
                                                } else {
                                                    // Handle case where the ad no longer exists in the database
                                                    ModelAd deletedAd = new ModelAd();
                                                    deletedAd.setId(adId); // Unique identifier for tracking
                                                    deletedAd.setTitle("This ad was deleted by the user");
                                                    deletedAd.setDeleted(true); // Custom flag to mark as deleted
                                                    adArrayList.add(deletedAd);
                                                    Log.w(TAG, "Ad with ID " + adId + " no longer exists.");
                                                }
                                            } catch (Exception e) {
                                                Log.e(TAG, "onDataChange: Error parsing ad data", e);
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            Log.e(TAG, "onCancelled: Failed to load ad data", error.toException());
                                        }
                                    });
                        }

                        // After data is loaded, update the adapter
                        new Handler().postDelayed(() -> {
                            adapterAd = new AdapterAd(mContext, adArrayList);
                            binding.adsRv.setAdapter(adapterAd);
                        }, 500);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e(TAG, "onCancelled: Failed to load favorites", error.toException());
                    }
                });
    }

    // Method to remove a deleted ad from favorites
    private void removeAdFromFavorites(String adId) {
        DatabaseReference favRef = FirebaseDatabase.getInstance().getReference("Users");
        favRef.child(firebaseAuth.getUid()).child("Favorites").child(adId).removeValue()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Optionally, show a message that the ad was deleted
                        Toast.makeText(mContext, "This ad was deleted by the user", Toast.LENGTH_SHORT).show();

                        // Now update the adapter to reflect the removal
                        loadAds(); // Or you can manually remove the ad from `adArrayList`
                    } else {
                        Log.e(TAG, "Error removing ad from favorites", task.getException());
                    }
                });
    }
}
