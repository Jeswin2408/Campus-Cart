package com.example.cart;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.cart.databinding.ActivityForgotPasswordBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPasswordActivity extends AppCompatActivity {

    private ActivityForgotPasswordBinding binding;
    private static final String TAG = "FORGOT_PASS_TAG";

    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    private String email = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize Firebase
        FirebaseApp.initializeApp(this);

        binding = ActivityForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize ProgressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait...");
        progressDialog.setCanceledOnTouchOutside(false);

        // Initialize FirebaseAuth
        firebaseAuth = FirebaseAuth.getInstance();

        // Back button click listener
        binding.toolbarBackBtn.setOnClickListener(view -> onBackPressed());

        // Submit button click listener
        binding.submitBtn.setOnClickListener(view -> validateData());

        // Handle system window insets for proper UI padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    /**
     * Validate the input email before proceeding.
     */
    private void validateData() {
        email = binding.emailEt.getText().toString().trim();

        Log.d(TAG, "validateData: email: " + email);

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailEt.setError("Invalid Email Pattern!");
            binding.emailEt.requestFocus();
        } else {
            sendPasswordRecoveryInstructions();
        }
    }

    /**
     * Send password reset instructions to the provided email.
     */
    private void sendPasswordRecoveryInstructions() {
        Log.d(TAG, "sendPasswordRecoveryInstructions: Sending to " + email);

        progressDialog.setMessage("Sending password recovery instructions to " + email);
        progressDialog.show();

        firebaseAuth.sendPasswordResetEmail(email)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        Utils.toast(ForgotPasswordActivity.this,
                                "Instructions to reset your password have been sent to " + email);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Log.e(TAG, "Failed to send password reset email: ", e);
                        Utils.toast(ForgotPasswordActivity.this,
                                "Failed to send email: " + e.getMessage());
                    }
                });
    }
}
